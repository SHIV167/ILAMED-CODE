# Stripe-Payment-Gateway-Integration-in-PHP
There are some Steps to integrate the Stripe payment gateway - 

1. We have to create an account on stripe.com
2. Then login into your account and Get a API (Test/Live) key from your account.
3. Create a Stripe checkout Form ( See my Form - STRIPE_FORM.PHP ).
4. Validate card through Stripe JavaScript library ( See my Form - STRIPE_FORM.PHP ).
5. Process Stripe charges in PHP and track the response ( See my Form - STRIPE_PAYMENT.PHP ).

Note : Download Stripe-Library From Github or run through Composer.
